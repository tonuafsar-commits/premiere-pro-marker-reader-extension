var MarkerTimestamps = MarkerTimestamps || {};

MarkerTimestamps.pad2 = function (value) {
  value = Math.floor(Number(value) || 0);
  return value < 10 ? "0" + value : String(value);
};

MarkerTimestamps.formatSeconds = function (seconds) {
  seconds = Math.max(0, Math.floor(Number(seconds) || 0));

  var hours = Math.floor(seconds / 3600);
  var minutes = Math.floor((seconds % 3600) / 60);
  var remainingSeconds = seconds % 60;

  if (hours > 0) {
    return MarkerTimestamps.pad2(hours) + ":" + MarkerTimestamps.pad2(minutes) + ":" + MarkerTimestamps.pad2(remainingSeconds);
  }

  return MarkerTimestamps.pad2(minutes) + ":" + MarkerTimestamps.pad2(remainingSeconds);
};

MarkerTimestamps.normalizeTimestampLines = function (content) {
  content = String(content || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  var lines = content.split("\n");
  var normalized = [];
  var index;
  var line;

  for (index = 0; index < lines.length; index += 1) {
    line = String(lines[index]).replace(/^\s+|\s+$/g, "");

    if (line) {
      normalized.push(line);
    }
  }

  return normalized.join("\n");
};

MarkerTimestamps.normalizeTimestampFileText = function (content) {
  return MarkerTimestamps.normalizeTimestampLines(content).replace(/\n/g, "\r\n");
};

MarkerTimestamps.cleanMarkerName = function (name) {
  if (typeof name === "undefined" || name === null) {
    return "";
  }

  return String(name).replace(/[\r\n\t]+/g, " ").replace(/^\s+|\s+$/g, "");
};

MarkerTimestamps.getActiveSequenceName = function () {
  try {
    if (app && app.project && app.project.activeSequence && app.project.activeSequence.name) {
      return String(app.project.activeSequence.name);
    }
  } catch (error) {}

  return "Marker Timestamps";
};

MarkerTimestamps.sanitizeFileName = function (name) {
  name = MarkerTimestamps.cleanMarkerName(name);
  name = name.replace(/[\\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").replace(/^\.+|\.+$/g, "");

  if (!name) {
    return "Marker Timestamps";
  }

  return name;
};

MarkerTimestamps.getSuggestedTxtFileName = function () {
  try {
    return MarkerTimestamps.sanitizeFileName(MarkerTimestamps.getActiveSequenceName()) + ".txt";
  } catch (error) {
    return "Marker Timestamps.txt";
  }
};

MarkerTimestamps.formatMarkerLine = function (marker) {
  var timestamp = MarkerTimestamps.formatSeconds(MarkerTimestamps.getMarkerSeconds(marker));
  var name = MarkerTimestamps.cleanMarkerName(marker.name);

  if (name) {
    return timestamp + " - " + name;
  }

  return timestamp;
};

MarkerTimestamps.getMarkerSeconds = function (marker) {
  if (!marker || !marker.start) {
    return 0;
  }

  if (typeof marker.start.seconds !== "undefined") {
    return marker.start.seconds;
  }

  if (typeof marker.start.ticks !== "undefined") {
    return Number(marker.start.ticks) / 254016000000;
  }

  return 0;
};

MarkerTimestamps.escapeJson = function (value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/"/g, "\\\"")
    .replace(/\r/g, "\\r")
    .replace(/\n/g, "\\n")
    .replace(/\t/g, "\\t");
};

MarkerTimestamps.markerToJson = function (marker) {
  var seconds = MarkerTimestamps.getMarkerSeconds(marker);
  var timestamp = MarkerTimestamps.formatSeconds(seconds);
  var name = MarkerTimestamps.cleanMarkerName(marker.name);
  var line = name ? timestamp + " - " + name : timestamp;

  return "{" +
    "\"time\":\"" + MarkerTimestamps.escapeJson(timestamp) + "\"," +
    "\"name\":\"" + MarkerTimestamps.escapeJson(name) + "\"," +
    "\"seconds\":" + Number(seconds || 0) + "," +
    "\"line\":\"" + MarkerTimestamps.escapeJson(line) + "\"" +
  "}";
};

MarkerTimestamps.getActiveSequenceMarkerTimes = function () {
  try {
    if (!app || !app.project) {
      return "ERROR:Premiere Pro project is not available.";
    }

    var sequence = app.project.activeSequence;
    if (!sequence) {
      return "ERROR:No active sequence found. Open a timeline and try again.";
    }

    if (!sequence.markers) {
      return "ERROR:This Premiere Pro version does not expose sequence markers to extensions.";
    }

    var markers = sequence.markers;
    var marker = markers.getFirstMarker();
    var timestamps = [];

    while (marker) {
      timestamps.push(MarkerTimestamps.formatMarkerLine(marker));
      marker = markers.getNextMarker(marker);
    }

    return timestamps.join("\r\n");
  } catch (error) {
    return "ERROR:" + error.toString();
  }
};

MarkerTimestamps.getActiveSequenceMarkersJson = function () {
  try {
    if (!app || !app.project) {
      return "ERROR:Premiere Pro project is not available.";
    }

    var sequence = app.project.activeSequence;
    if (!sequence) {
      return "ERROR:No active sequence found. Open a timeline and try again.";
    }

    if (!sequence.markers) {
      return "ERROR:This Premiere Pro version does not expose sequence markers to extensions.";
    }

    var markers = sequence.markers;
    var marker = markers.getFirstMarker();
    var jsonItems = [];

    while (marker) {
      jsonItems.push(MarkerTimestamps.markerToJson(marker));
      marker = markers.getNextMarker(marker);
    }

    return "[" + jsonItems.join(",") + "]";
  } catch (error) {
    return "ERROR:" + error.toString();
  }
};

MarkerTimestamps.seekToSeconds = function (seconds) {
  try {
    if (!app || !app.project) {
      return "ERROR:Premiere Pro project is not available.";
    }

    var sequence = app.project.activeSequence;
    if (!sequence) {
      return "ERROR:No active sequence found. Open a timeline and try again.";
    }

    if (typeof sequence.setPlayerPosition !== "function") {
      return "ERROR:This Premiere Pro version does not support playhead jumping from extensions.";
    }

    var ticks = Math.max(0, Math.round(Number(seconds || 0) * 254016000000));
    sequence.setPlayerPosition(String(ticks));

    return "OK";
  } catch (error) {
    return "ERROR:" + error.toString();
  }
};

MarkerTimestamps.saveTextFile = function (content) {
  var file;

  try {
    var defaultFile = new File("~/Desktop/" + MarkerTimestamps.getSuggestedTxtFileName());

    file = defaultFile.saveDlg("Save marker timestamps", "Text Files:*.txt");

    if (!file) {
      return "CANCELLED";
    }

    if (!/\.txt$/i.test(file.fsName)) {
      file = new File(file.fsName + ".txt");
    }

    file.encoding = "UTF-8";

    if (!file.open("w")) {
      return "ERROR:Could not open the selected file for writing.";
    }

    file.write(MarkerTimestamps.normalizeTimestampFileText(content));
    file.close();

    return file.fsName;
  } catch (error) {
    try {
      if (file && file.opened) {
        file.close();
      }
    } catch (closeError) {}

    return "ERROR:" + error.toString();
  }
};
